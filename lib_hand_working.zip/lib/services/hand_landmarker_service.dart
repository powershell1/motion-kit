import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

class HandLandmark {
  final double x;
  final double y;
  final double z;

  const HandLandmark({
    required this.x,
    required this.y,
    required this.z,
  });

  factory HandLandmark.fromMap(Map<String, dynamic> map) {
    return HandLandmark(
      x: (map['x'] as num).toDouble(),
      y: (map['y'] as num).toDouble(),
      z: (map['z'] as num).toDouble(),
    );
  }
}

class HandLandmarkerService {
  static const MethodChannel _channel = MethodChannel('com.powershell1.motion_kit/hand_landmarker');

  /// Detect hand landmarks from camera input image
  static Future<List<HandLandmark>> detectHandLandmarks(InputImage inputImage) async {
    try {
      // Convert InputImage to the format expected by native code
      final bytes = inputImage.bytes;
      if (bytes == null) {
        throw Exception('Image bytes are null');
      }

      final metadata = inputImage.metadata;
      if (metadata == null) {
        throw Exception('Image metadata is null');
      }

      // Get rotation in degrees
      final rotation = _getRotationDegrees(metadata.rotation);

      final result = await _channel.invokeMethod('detect', {
        'bytes': bytes,
        'width': metadata.size.width.toInt(),
        'height': metadata.size.height.toInt(),
        'rotation': rotation,
      });

      if (result is List) {
        return result
            .cast<Map<dynamic, dynamic>>()
            .map((landmark) => HandLandmark.fromMap(Map<String, dynamic>.from(landmark)))
            .toList();
      }

      return [];
    } catch (e) {
      print('Error detecting hand landmarks: $e');
      return [];
    }
  }

  static int _getRotationDegrees(InputImageRotation rotation) {
    switch (rotation) {
      case InputImageRotation.rotation0deg:
        return 0;
      case InputImageRotation.rotation90deg:
        return 90;
      case InputImageRotation.rotation180deg:
        return 180;
      case InputImageRotation.rotation270deg:
        return 270;
    }
  }
}
