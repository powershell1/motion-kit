import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_pose_detection/google_mlkit_pose_detection.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:vector_math/vector_math.dart';

import '../services/hand_landmarker_service.dart';
import 'detector_view.dart';
import 'painters/hand_pose_painter.dart';

class HandPoseDetectorView extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _HandPoseDetectorViewState();
}

class _HandPoseDetectorViewState extends State<HandPoseDetectorView> {
  final PoseDetector _poseDetector = PoseDetector(
    options: PoseDetectorOptions(
      mode: PoseDetectionMode.stream,
      model: PoseDetectionModel.base,
    ),
  );
  
  bool _canProcess = true;
  bool _isBusy = false;
  CustomPaint? _customPaint;
  String? _text;
  var _cameraLensDirection = CameraLensDirection.back;
  
  // Display options
  bool _showHandNumbers = false;
  bool _showPoseNumbers = false;
  bool _showConnections = false;

  @override
  void dispose() async {
    _canProcess = false;
    _poseDetector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hand & Pose Detection'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              setState(() {
                switch (value) {
                  case 'hand_numbers':
                    _showHandNumbers = !_showHandNumbers;
                    break;
                  case 'pose_numbers':
                    _showPoseNumbers = !_showPoseNumbers;
                    break;
                  case 'connections':
                    _showConnections = !_showConnections;
                    break;
                }
              });
            },
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'hand_numbers',
                child: Row(
                  children: [
                    Icon(_showHandNumbers ? Icons.check_box : Icons.check_box_outline_blank),
                    const SizedBox(width: 8),
                    const Text('Show Hand Numbers'),
                  ],
                ),
              ),
              PopupMenuItem<String>(
                value: 'pose_numbers',
                child: Row(
                  children: [
                    Icon(_showPoseNumbers ? Icons.check_box : Icons.check_box_outline_blank),
                    const SizedBox(width: 8),
                    const Text('Show Pose Numbers'),
                  ],
                ),
              ),
              PopupMenuItem<String>(
                value: 'connections',
                child: Row(
                  children: [
                    Icon(_showConnections ? Icons.check_box : Icons.check_box_outline_blank),
                    const SizedBox(width: 8),
                    const Text('Show Connections'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: DetectorView(
        title: 'Hand & Pose Detector',
        customPaint: _customPaint,
        text: _text,
        onImage: _processImage,
        initialCameraLensDirection: _cameraLensDirection,
        onCameraLensDirectionChanged: (value) => _cameraLensDirection = value,
      ),
    );
  }

  Future<void> _processImage(InputImage inputImage) async {
    if (!_canProcess) return;
    if (_isBusy) return;
    _isBusy = true;
    
    setState(() {
      _text = '';
    });
    
    try {
      // Process both pose and hand detection simultaneously
      final futures = await Future.wait([
        _poseDetector.processImage(inputImage),
        HandLandmarkerService.detectHandLandmarks(inputImage),
      ]);
      
      final poses = futures[0] as List<Pose>;
      final handLandmarks = futures[1] as List<HandLandmark>;
      
      if (inputImage.metadata?.size != null &&
          inputImage.metadata?.rotation != null) {
        final painter = HandPosePainter(
          poses,
          handLandmarks,
          inputImage.metadata!.size,
          inputImage.metadata!.rotation,
          _cameraLensDirection,
          showHandNumbers: _showHandNumbers,
          showPoseNumbers: _showPoseNumbers,
          showConnections: _showConnections,
        );
        _customPaint = CustomPaint(painter: painter);

        final landmarks = poses[0].landmarks;
        PoseLandmark rightShoulder = landmarks[PoseLandmarkType.rightShoulder]!;
        PoseLandmark leftShoulder = landmarks[PoseLandmarkType.leftShoulder]!;

        Vector3 centerShoulder = Vector3(
          (rightShoulder.x + leftShoulder.x) / 2,
          (rightShoulder.y + leftShoulder.y) / 2,
          (rightShoulder.z + leftShoulder.z) / 2,
        );
        Vector3 rightCollarbone = Vector3(
            (centerShoulder.x + rightShoulder.x) / 2,
            (centerShoulder.y + rightShoulder.y) / 2 - 1, // Adjusted for better visibility
            (centerShoulder.z + rightShoulder.z) / 2
        );
        Vector3 leftCollarbone = Vector3(
            (centerShoulder.x + leftShoulder.x) / 2,
            (centerShoulder.y + leftShoulder.y) / 2 - 1, // Adjusted for better visibility
            (centerShoulder.z + leftShoulder.z) / 2
        );

        double distance = (rightShoulder.x - leftShoulder.x).abs();
        double radius = distance / 10; // Adjust radius based on distance

        painter.drawCircle(rightCollarbone.x, rightCollarbone.y, radius);
        painter.drawCircle(leftCollarbone.x, leftCollarbone.y, radius);
        
        // Analyze the combined detection results
        // _text = _analyzeCombinedDetection(poses, handLandmarks);
      } else {
        _text = 'Poses: ${poses.length}, Hand landmarks: ${handLandmarks.length}';
        _customPaint = null;
      }
    } catch (e) {
      _text = 'Error: $e';
      _customPaint = null;
    }
    
    _isBusy = false;
    if (mounted) {
      setState(() {});
    }
  }
}
